# Giới thiệu R cho Nghiên cứu Lâm sàng (VN)

Overleaf project. Upload this folder (or the zip) to Overleaf, then set **Menu → Compiler → XeLaTeX**. `main.tex` is the main document; chapters are in `chapters/`, figures in `figures/`, references in `references.bib` (biber).
