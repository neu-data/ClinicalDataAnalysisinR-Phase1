# Introduction to R for Clinical Research (EN)

Overleaf project. Upload this folder (or the zip) to Overleaf, then set **Menu → Compiler → XeLaTeX**. `main.tex` is the main document; chapters are in `chapters/`, figures in `figures/`, references in `references.bib` (biber).
