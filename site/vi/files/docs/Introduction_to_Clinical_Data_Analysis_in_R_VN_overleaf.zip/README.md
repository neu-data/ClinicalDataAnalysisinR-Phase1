# Nhập môn Phân tích Dữ liệu Lâm sàng bằng R (VN)

Overleaf project. Upload this folder (or the zip) to Overleaf, then set **Menu → Compiler → LuaLaTeX**. `main.tex` is the main document; chapters are in `chapters/`, figures in `figures/`, references in `references.bib` (biber).
